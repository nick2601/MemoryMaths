# flutter_email_sender_example

Demonstrates how to use the flutter_email_sender plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
