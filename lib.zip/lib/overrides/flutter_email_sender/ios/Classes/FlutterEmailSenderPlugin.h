#import <Flutter/Flutter.h>

@interface FlutterEmailSenderPlugin : NSObject<FlutterPlugin>
@end
