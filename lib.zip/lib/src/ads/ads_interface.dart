// import 'package:google_mobile_ads/google_mobile_ads.dart';
//
//
// abstract class AdsInterfaces {
//   void onAdLoad(InterstitialAd interstitialAds);
//   void onAdClose();
// }
