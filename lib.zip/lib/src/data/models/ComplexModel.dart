class ComplexModel{

  String? question;
  String? finalAnswer;
  String? answer;
  List<String> optionList=[];
}