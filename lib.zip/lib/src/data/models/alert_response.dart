class AlertResponse {
  final bool exit;
  final bool restart;
  final bool play;

  AlertResponse({required this.exit,required  this.restart, required this.play});
}
