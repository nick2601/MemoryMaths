

class DuelScoreModel{


  String? title, subTitle;
   int score=0;
}