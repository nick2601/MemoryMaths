
class FindMissingQuizModel {
  String? sign;
  String? rem;
  int? id;
  String? firstDigit;
  String? secondDigit, question;
  String? answer;
  String? op_1;
  String? op_2;
  String? op_3;

  List<String> optionList = [];






}
