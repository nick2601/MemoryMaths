class ModelWorkoutData {
  String? question;
  String? answer;
  String? optA;
  String? optB;
  String? optC;
}
