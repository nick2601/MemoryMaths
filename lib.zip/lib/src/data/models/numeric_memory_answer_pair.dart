class NumericMemoryAnswerPair{


  String? key;
  bool? isCheck;



}