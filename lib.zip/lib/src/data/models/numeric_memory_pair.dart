import 'numeric_memory_answer_pair.dart';

class NumericMemoryPair{


  String? answer;
  int? question;
  List<NumericMemoryAnswerPair> list=[];

}