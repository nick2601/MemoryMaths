import 'package:flutter/cupertino.dart';

class GradientModel{
  Color? primaryColor;
  Color? cellColor;
  Color? bgColor;
  Color? gridColor;
  Color? backgroundColor;
  String? folderName;
}